$(function(){
    //Esto es para el MENU
    setTimeout(function(){$("#lavaLamp").lavaLamp({fx: "backout", speed: 700})}, 2000);

   
});

