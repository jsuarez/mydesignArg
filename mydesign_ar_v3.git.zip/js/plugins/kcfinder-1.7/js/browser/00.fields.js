var browser = {
    labels: [],
    shows: [],
    orders: [],
    wysiwyg: {}
};
