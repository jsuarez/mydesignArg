<?php
if( $LOAD=="js" ){
    $arr[] = "plugins/jquery.flip.0-9-9/jquery-ui-1.7.2.custom.min";
    $arr[] = "plugins/jquery.flip.0-9-9/jquery.flip.min";
}
?>