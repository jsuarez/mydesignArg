<?php
if( $LOAD=="js" ){
    $arr[] = "class/services_front_class".$this->config->item('sufix_pack_js');
}
?>