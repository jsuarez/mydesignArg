<?php
if( $LOAD=="js" ){
    $arr[] = "plugins/jquery.cycle.all.min";
}
?>