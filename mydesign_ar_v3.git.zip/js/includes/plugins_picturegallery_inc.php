<?php
if( $LOAD=="js" ){
    $arr[] = "plugins/picturegallery/picturegallery.min";
}
?>