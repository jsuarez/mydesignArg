<?php
$arr[] = "jquery-1.4.2.min";
$arr[] = "baseuri";
$arr[] = "helpers/helpers".$this->config->item('sufix_pack_js');
$arr[] = "plugins/lavalamp_0.1.0/jquery.lavalamp.min";
$arr[] = "plugins/lavalamp_0.1.0/jquery.easing.min";
$arr[] = "general_panel".$this->config->item('sufix_pack_js');
?>