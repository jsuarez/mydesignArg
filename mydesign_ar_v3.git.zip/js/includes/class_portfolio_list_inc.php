<?php
if( $LOAD=="js" ){
    $arr[] = "class/portfolio_list_class".$this->config->item('sufix_pack_js');
}
?>