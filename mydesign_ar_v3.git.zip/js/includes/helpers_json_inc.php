<?php
if( $LOAD=="js" ){
    $arr[] = "helpers/json/JSONError".$this->config->item('sufix_pack_js');
    $arr[] = "helpers/json/JSON".$this->config->item('sufix_pack_js');
}
?>