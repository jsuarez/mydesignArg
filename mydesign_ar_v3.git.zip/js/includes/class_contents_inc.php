<?php
if( $LOAD=="js" ){
    $arr[] = "class/contents_class".$this->config->item('sufix_pack_js');
}
?>