<?php
echo '<script type="text/javascript" src="js/plugins/jquery-ui.sortable/jquery-ui-1.8.2.custom.min.js"></script>';
?>