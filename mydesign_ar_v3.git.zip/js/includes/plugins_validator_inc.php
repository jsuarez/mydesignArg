<?php
$arr[] = "plugins/jquery-validate/jquery.validate.pack";
$arr[] = "plugins/jquery-validate/localization/messages_es";
$arr[] = "plugins/jquery-validate/config";
?>