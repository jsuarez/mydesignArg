<?php
if( $LOAD=="js" ){
    $arr[] = "plugins/carousel/carousel-script";
}else{
    $arr[] = "js/plugins/carousel/carousel-style";    
}
?>