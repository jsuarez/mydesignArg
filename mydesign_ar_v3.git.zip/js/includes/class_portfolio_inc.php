<?php
if( $LOAD=="js" ){
    $arr[] = "class/portfolio_class".$this->config->item('sufix_pack_js');
}
?>