<?php
echo '<link rel="stylesheet" href="js/plugins/jquery-ui-tabs/css/cupertino/jquery-ui-1.8.6.custom.css" type="text/css" media="screen, projection" />';
echo '<script type="text/javascript" src="js/plugins/jquery-ui-tabs/js/jquery-ui-1.8.6.custom.min.js"></script>';
?>