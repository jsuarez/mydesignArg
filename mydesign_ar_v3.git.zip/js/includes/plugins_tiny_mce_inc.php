<?php
echo '<script type="text/javascript" src="js/plugins/tinymce/tiny_mce.js"></script>';
echo '<script type="text/javascript" src="js/plugins/tinymce/init.js"></script>';
?>