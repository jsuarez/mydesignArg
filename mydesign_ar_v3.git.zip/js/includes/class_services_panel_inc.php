<?php
if( $LOAD=="js" ){
    $arr[] = "class/services_panel_class".$this->config->item('sufix_pack_js');
}
?>