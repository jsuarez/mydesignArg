<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['full_tag_open']  = '<div class="pagination">';
$config['full_tag_close'] = '</div>';
$config['next_link']      = 'Siguiente';
$config['prev_link']      = 'Anterior';
$config['first_link']     = 'Primero';
$config['last_link']      = 'Ultimo';
$config['num_links']      = 2;
?>
